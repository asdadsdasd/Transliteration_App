﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <string>
#include <ctype.h>
#include <locale.h>
#include <windows.h>
#include <fstream>
#include <vector>
#include <map>


using namespace std;

/*!
* Функция выполняет открытие файла с английсим текстом и считывает его содержимое в строку
* \return - возвращает введенныую пользователем строку
* Если файл открыть не удаось, то приводит к остановке программы
*/
string inputFile(string fileName);

/*!
* Функция заменяет первое входнеие слова в строке на точки
* \param [in] eng - введенная пользователем строка
* \return - возвращает строку после транслитерации на русский язык
*/
vector<string> translit(string eng);

/*!
* Функция выводит результат транслитерации в txt файл
* \param [in] ru - строка после транслитерации на русский язык
*/
void outputFile(vector<string> ru, string outputFileName);

/*!
* Функция инициализирует карту перевода DecMap
*/
void setDecMap();

/*!
* Функция заменяет все символы строки на большие по регистру
* \param [in] line - введенная пользователем строка
* \return - возвращает строку символов в верхнем регистре
*/
string toupper(string line);

/*!
* Функция заменяет символ на большой
* \param [in] ch - переданный в функцию символ
* \return - возвращает символ в верхнем регистре
*/
char toupper(char ch);

/*!
* Функция заменяет символ на маленький
* \param [in] ch - переданный в функцию символ
* \return - возвращает символ в нижнем регистре
*/
char tolower(char ch);

int maxCombLen = 3;

int main()
{
    setlocale(LC_ALL, "ru");
    setDecMap();
    string line;

    printf("Input name of txt file with english text: ");
    string inputFileName;
    cin >> inputFileName;

    line = inputFile(inputFileName);
    vector<string> ru = translit(line);

    printf("\nInput name of txt file you would like to record the translited version: ");
    string outputFileName;
    cin >> outputFileName;

    outputFile(ru, outputFileName);

    return 0;
}


string inputFile(string fileName)
{
    ifstream fin;

    fin.open(fileName);
    if (!fin.is_open())
    {
        printf("Ошибка при открытии файла!\n");
        exit(EXIT_FAILURE);
    }

    string line;

    int count = 0;
    while (!fin.eof())
    {
        getline(fin, line);
        count++;
    }
    if (count > 1)
    {
        printf("Количество строк в файле не равно 1!\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < line.length(); i++)
    {
        if (!((line[i] >= 'A' && line[i] <= 'Z') || (line[i] >= 'a' && line[i] <= 'z') || line[i] == ' '))
        {
            printf("В исходной строке есть недопустимые символы!\n");
            exit(EXIT_FAILURE);
        }
    }

    cout << line << endl;

    fin.close();
    return line;
}


map<string, vector<string>>decMap;


void setDecMap() {
    decMap["a"] = { "а" };
    decMap["b"] = { "б" };
    decMap["c"] = { "ц" };
    decMap["d"] = { "д" };
    decMap["e"] = { "е" };
    decMap["f"] = { "ф" };
    decMap["g"] = { "г" };
    decMap["h"] = { "х" };
    decMap["i"] = { "и" };
    decMap["j"] = { "дж" };
    decMap["k"] = { "к" };
    decMap["l"] = { "л" };
    decMap["m"] = { "м" };
    decMap["n"] = { "н" };
    decMap["o"] = { "о" };
    decMap["p"] = { "п" };
    decMap["q"] = { "ку" };
    decMap["r"] = { "р" };
    decMap["s"] = { "с" };
    decMap["t"] = { "т" };
    decMap["u"] = { "у" };
    decMap["v"] = { "в" };
    decMap["w"] = { "в" };
    decMap["x"] = { "кс" };
    decMap["y"] = { "й" };
    decMap["z"] = { "з" };
    decMap["yo"] = { "ё" };
    decMap["yu"] = { "ю" };
    decMap["ya"] = { "я" };
    decMap["ye"] = { "е" };
    decMap["zh"] = { "ж" };
    decMap["sh"] = { "ж" };
    decMap["kh"] = { "х" };
    decMap["eh"] = { "э" };
    decMap["ih"] = { "ы" };
    decMap["ts"] = { "ц" };
    decMap["ch"] = { "ч" };
    decMap["A"] = { "А" };
    decMap["B"] = { "Б" };
    decMap["C"] = { "Ц" };
    decMap["D"] = { "Д" };
    decMap["E"] = { "Е" };
    decMap["F"] = { "Ф" };
    decMap["G"] = { "Г" };
    decMap["H"] = { "Х" };
    decMap["I"] = { "И" };
    decMap["J"] = { "Дж" };
    decMap["K"] = { "К" };
    decMap["L"] = { "Л" };
    decMap["M"] = { "М" };
    decMap["N"] = { "Н" };
    decMap["O"] = { "О" };
    decMap["P"] = { "П" };
    decMap["Q"] = { "Ку" };
    decMap["R"] = { "Р" };
    decMap["S"] = { "С" };
    decMap["T"] = { "Т" };
    decMap["U"] = { "У" };
    decMap["V"] = { "В" };
    decMap["W"] = { "В" };
    decMap["X"] = { "Кс" };
    decMap["Y"] = { "Й" };
    decMap["Z"] = { "З" };
    decMap["Yo"] = { "Ё" };
    decMap["Yu"] = { "Ю" };
    decMap["Ya"] = { "Я" };
    decMap["Ye"] = { "Е" };
    decMap["Zh"] = { "Ж" };
    decMap["Sh"] = { "Ш" };
    decMap["Kh"] = { "Х" };
    decMap["Eh"] = { "Э" };
    decMap["Ih"] = { "Ы" };
    decMap["Ts"] = { "Ц" };
    decMap["Ch"] = { "Ч" };
    decMap[" "] = { " " };
}


//Массив уже переведённой части строки, чтобы не переводить уже переведённое
vector<vector<string>>decodes;

//Массив символов верхнего регистра для восстановления регистра после перевода
vector<bool>upper;


vector<string> decodeString(string& line, int pos) {
    //Если строка с этой позиции уже была переведена, то возвращаем старый результат
    if (decodes[pos].size() > 0)
        return decodes[pos];
    else {
        //Массив вариантов перевода res
        vector<string>res;
        //Перебираем длину комбинации символов для перевода (от 1 до maxCombLen)
        for (int len = 1; (len <= maxCombLen) && (pos + len <= line.size()); ++len) {
            vector<string>& curVars = decMap[line.substr(pos, len)],
                leftVars = decodeString(line, pos + len);
            //Если в изначальной строке символ, соответствующий pos был в верхнем регистре,
            //устанавливаем все curVars в верхний регистр
            if (upper[pos])
                for (int i = 0; i < curVars.size(); ++i)
                    curVars[i] = toupper(curVars[i]);
            for (int i = 0; i < curVars.size(); ++i)
                for (int j = 0; j < leftVars.size(); ++j)
                    res.push_back(curVars[i] + leftVars[j]);
        }
        decodes[pos] = res;
        return res;
    }
}


char tolower(char ch) {
    return static_cast<char>(tolower(static_cast<unsigned char>(ch)));
}

char toupper(char ch) {
    return static_cast<char>(toupper(static_cast<unsigned char>(ch)));
}


string toupper(string line) {
    for (int i = 0; i < line.size(); ++i)
        line[i] = toupper(line[i]);
    return line;
}


string makeLow(string line) {
    upper.resize(line.size());
    for (int i = 0; i < line.size(); ++i) {
        char c = tolower(line[i]);
        upper[i] = (c != line[i]);
        line[i] = c;
    }
    return line;
}


vector<string> translit(string eng)
{
    //понижаем регистр строки для упрощения карты перевода и запоминаем символы верхнего регистра
    string copy = makeLow(eng);
    decodes.resize(copy.size() + 1);
    decodes[copy.size()] = { "" };
    //переводим строку, начиная с первого символа (позиции 0)
    vector<string>ru = decodeString(copy, 0);
    //возвращаем массив строк ru
    return ru;
}


void outputFile(vector<string> ru, string outputFileName)
{
    ofstream fout;

    fout.open(outputFileName);
    if (!fout.is_open())
    {
        printf("Ошибка при открытии файла!\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < ru.size(); ++i)
        fout << ru[i] << endl;

    fout.close();
}